<?php


return [
    'host' => 'http://singwa.swoole.com:8811',
];